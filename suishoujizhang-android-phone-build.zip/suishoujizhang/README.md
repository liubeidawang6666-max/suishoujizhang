# 随手记账 Android 项目

- 产品：随手记账 1.0.0
- 设计：蓝白简约
- 存储：完全离线，账单保存在 WebView 本地存储（localStorage）
- 网络权限：未申请网络权限，不会联网
- Android：minSdk 23（Android 6.0），targetSdk 34；Java/Kotlin 编译目标统一为 17

## 当前功能

- 收入、支出录入：金额、分类、账户、日期、备注
- 首页月收入/月支出/月结余、最近账单、日均支出、笔数
- 账单月份切换、关键词搜索、删除
- 月度统计、分类占比条、最近 7 天支出趋势
- 月总预算、分类预算及执行进度
- 账户管理、初始余额、资产余额汇总
- 自定义收入/支出分类
- JSON 备份导出到 Download 文件夹、文件选择导入恢复
- 数据清空、深色外观切换

## 使用 Android Studio 打包 APK

1. 在电脑安装 Android Studio（免费）及 Android SDK 35。
2. 用 Android Studio 打开本项目文件夹 `suishoujizhang`。
3. 等待 Gradle Sync 完成（首次构建需要联网下载 Android Gradle Plugin 和 SDK 组件）。
4. 选择 Build → Build Bundle(s) / APK(s) → Build APK(s)。
5. APK 默认输出在 `app/build/outputs/apk/debug/app-debug.apk`。

也可在 Android Studio Terminal 执行：`gradle assembleDebug`（前提是已安装 Gradle 与 Android SDK）。

## 重要说明

当前运行环境没有 Android SDK、Gradle，也无法访问外网下载构建依赖，因此这里不能实际编译并验证 APK。项目源码已准备好，但不能把源码 ZIP 冒充 APK。首次在 Android Studio 构建后即可生成可安装的 debug APK。

账单仅存本机。清除应用数据、卸载应用或系统清理应用数据可能导致记录丢失，请定期使用“导出数据备份”。账户余额按初始余额 + 关联收入 - 关联支出计算。当前版本未实现账户间转账、自动周期账单、密码/生物识别锁和系统级定时通知；这些可在后续版本补齐。

## 只有安卓手机时：使用 GitHub 免费云端构建

本项目已附带 GitHub Actions 工作流 `.github/workflows/build-apk.yml`。它会在 GitHub 云端编译 APK，不需要在手机安装 Android Studio。

1. 在手机浏览器打开 https://github.com ，注册/登录并创建一个 **Public** 仓库（例如 `suishoujizhang`）。
2. 将本项目解压后，把项目内所有文件和文件夹上传到仓库根目录；务必包含隐藏目录 `.github/workflows/`。
3. 上传完成后，进入仓库的 **Actions** 页面，选择 **Build Android APK**，点 **Run workflow**。
4. 等待运行完成（绿色勾号），打开该次运行页面，在 **Artifacts** 区域下载 `suishoujizhang-debug-apk`。
5. 解压下载的 artifact，找到 `app-debug.apk`，点击安装。若系统提示，允许浏览器/文件管理器“安装未知应用”。

说明：GitHub 对公开仓库的 Actions 有免费额度；若仓库设为私有，免费额度受账户限制。APK 是 debug 签名，适合个人安装测试；正式发布或长期升级需要另行配置自己的签名密钥。账单数据仅存本机，卸载或清除应用数据可能丢失，请定期导出备份。
